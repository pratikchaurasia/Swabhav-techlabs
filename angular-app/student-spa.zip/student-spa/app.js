angular.module("student-spa", ["ngRoute", "swabhav.controllers"])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when("/students", {
            templateUrl: "partial/students.html",
            controller: "studentCtrl"
        })
        $routeProvider.when("/", {
            templateUrl: "partial/students.html",
            controller: "studentCtrl"
        })
        $routeProvider.when("/delete", {
            templateUrl: "partial/students.html",
            controller: "deleteCtrl"
        })
        $routeProvider.when("/add", {
            templateUrl: "partial/add.html",
            controller: "addCtrl"
        })

    }])