angular.module("swabhav.controllers", [])
    .controller('studentCtrl', ['$scope', '$log', 'dataservice', function ($scope, $log, dataservice) {
        $scope.search = function () {
            dataservice.getData().then(function (r) {
                $scope.result = r.data;
                console.log($scope.result);
            });
        };
        $scope.search();
    }])
    .controller('deleteCtrl', ['$scope', '$log', 'dataservice', function ($scope, $log, dataservice) {
        $scope.deleteStudent = function (student) {
            dataservice.removeStudent(student).then(function (r) {
                $scope.search();
            });
        };
    }])
    .controller('addCtrl', ['$scope', '$log','$location' ,'dataservice', function ($scope, $log,$location,dataservice) {
        $scope.studentAdd = function () {
            var rollNo = $scope.rollNo;
            var name = $scope.name;
            var age = $scope.age;
            var email = $scope.email;
            var date = $scope.date;
            var isMale = false;
            if ($scope.isMale) {
                var isMale = true;
            }

            var student = {
                rollNo,
                name,
                age,
                email,
                date,
                isMale
            }
            dataservice.addStudent(student).then(function (r) {
                $location.path('/students/' ).replace();
                
            })
        }
    }]);



angular.module("swabhav.controllers").factory('dataservice', ['$http', function ($http) {
    var url = "http://gsmktg.azurewebsites.net:80/api/v1/techlabs/test/students/";
    var obj = {}
    obj.getData = (function () {
        return $http.get(url);
    })
    obj.removeStudent = (function (studentID) {
        return $http.delete(url + studentID);
    })
    obj.addStudent = (function (student) {
        return $http.post(url, student);
    })
    obj.updateStudent = (function (student) {
        return $http.post(url, student);
    })
    return obj;
}]);